#include <gl/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <cmath>
#include <vector>

// GLM includes
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "camera.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
/**********************/

// ---- Variables ----

const char* WINDOW_TITLE = "Valletta";     // Window title
const int WINDOW_WIDTH = 1280;           // Window width
const int WINDOW_HEIGHT = 720;          // Window height

// Obvious
const float PI = 3.14159265359f;

// Store some colors
const float vertexColors[6][4] = {
	{0.11f, 0.69f, 0.96f, 1.00f},
	{1.00f, 0.29f, 0.29f, 1.00f},
	{1.00f, 0.78f, 0.00f, 1.00f},
	{1.00f, 0.59f, 0.00f, 1.00f},
	{0.81f, 0.51f, 1.00f, 1.00f},
	{0.17f, 0.44f, 0.79f, 1.00f}
};

// Camera variables
Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
float gLastX = WINDOW_WIDTH / 2.0f;
float gLastY = WINDOW_HEIGHT / 2.0f;
bool gFirstMouse = true;

float deltaTime = 0.0f;
float lastFrame = 0.0f;

float normalCamSpeed = 0.9f;
float slowCamSpeed = 0.5f;

// Create a projection matrix
float aspectRatio = (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT;

// Create perspective projection matrix
glm::mat4 perspective = glm::perspective(
	glm::radians(gCamera.Zoom),
	aspectRatio,
	0.1f,
	100.0f
);

// Create orthographic perspective matrix
// Orthographic perspective sucks
glm::mat4 orthographic = glm::ortho(
	-7.0f,
	7.0f,
	-5.0f,
	5.0f,
	0.1f,
	100.0f
);

// Set the project matrix equal to the perspective matrix by default
glm::mat4 projection = perspective;

// Going to hold our window object (null for the time being)
GLFWwindow* window = nullptr;

// Shader program ID
unsigned int shaderProgramId;
unsigned int lightProgramId;

unsigned int textureCount = 0;

static glm::vec2 uv_scale;

void flipImageVertically(unsigned char* image, int width, int height, int channels);

// Base mesh class
class Mesh {
public:
	unsigned int VAO;
	unsigned int VBOs[2];
	unsigned int nVertices = 0;
	unsigned int nIndices = 0;
	std::vector<float> vertices;
	std::vector<unsigned int> indices;
	glm::vec3 objectColor = glm::vec3(1.0f, 1.0f, 1.0f);
};

// Cylinder class, inherts from Mesh
class Cylinder : public Mesh {
private:
	// Number of triangles or steps to use to build the cylinder
	// Higher = better, but more triangles used
	unsigned int steps;

	// Cylinder radius
	float radius;

	// Cylinder height
	float height;

	// Used to calculate the angle of each step or triangle
	float sectorStep;

public:
	// Constructor
	Cylinder(unsigned int steps, float radius, float height) {
		// Set the steps, radius, and height
		this->steps = steps;
		this->radius = radius;
		this->height = height;

		// Set the step for each sector based on how many steps are given
		this->sectorStep = (2 * PI) / this->steps;

		// Calculate where the vertices go and store them in the vertices vector
		this->calculateVertices();

		// Calculate what vertices need to be connected to each other
		// and store them in the indices vector
		this->calculateIndices();
	}

	// Calculate the vertices for each triangle in the cylinder
	void calculateVertices() {
		// Used for color
		unsigned int floatsPerColor = 4;
		unsigned int vertexColorsSize = sizeof(vertexColors) / sizeof(float);

		// Set the origin point for the origin of the top of the cylinder
		glm::vec3 currentVertex = glm::vec3(0.0f, 0.0f, (this->height / 2));

		glm::vec2 textureCoordinates = glm::vec2(currentVertex.x, currentVertex.z);

		glm::vec3 normals = glm::vec3(currentVertex.x, currentVertex.y, currentVertex.z);

		// Generate the top of the cylinder
		this->vertices.push_back(currentVertex.x);
		this->vertices.push_back(currentVertex.y);
		this->vertices.push_back(currentVertex.z);

		this->vertices.push_back(textureCoordinates.x);
		this->vertices.push_back(textureCoordinates.y);

		this->vertices.push_back(normals.x);
		this->vertices.push_back(normals.y);
		this->vertices.push_back(normals.z);

		this->nVertices++;

		// Do some math to find out where each of the vertices should go for the top
		for (unsigned int i = 0; i < this->steps; i++) {
			// Calculate the angle
			float angle = i * this->sectorStep;

			// Set the x and y coordinates
			currentVertex.x = (this->radius * cos(angle));
			currentVertex.y = (this->radius * sin(angle));

			// Push these vertices to the vertices vector
			this->vertices.push_back(currentVertex.x);
			this->vertices.push_back(currentVertex.y);
			this->vertices.push_back(currentVertex.z);

			textureCoordinates.x = currentVertex.x;
			textureCoordinates.y = currentVertex.z;

			this->vertices.push_back(textureCoordinates.x);
			this->vertices.push_back(textureCoordinates.y);

			normals.x = currentVertex.x;
			normals.y = currentVertex.y;
			normals.z = currentVertex.z;

			this->vertices.push_back(normals.x);
			this->vertices.push_back(normals.y);
			this->vertices.push_back(normals.z);

			this->nVertices++;
		}

		// Set the origin point for the bottom of the cylinder
		currentVertex = glm::vec3(0.0f, 0.0f, -(this->height / 2));
		textureCoordinates = glm::vec2(currentVertex.x, currentVertex.z);
		normals = glm::vec3(currentVertex.x, currentVertex.y, currentVertex.z);

		// Generate the bottom of the cylinder
		this->vertices.push_back(currentVertex.x);
		this->vertices.push_back(currentVertex.y);
		this->vertices.push_back(currentVertex.z);

		this->vertices.push_back(textureCoordinates.x);
		this->vertices.push_back(textureCoordinates.y);

		this->vertices.push_back(normals.x);
		this->vertices.push_back(normals.y);
		this->vertices.push_back(normals.z);

		this->nVertices++;

		// Calculate the position of the vertices for the bottom of the cylinder
		for (unsigned int i = 0; i < this->steps; i++) {
			// Calculate the angle
			float angle = i * this->sectorStep;

			// Set the x and y positions of the vertex
			currentVertex.x = (this->radius * cos(angle));
			currentVertex.y = (this->radius * sin(angle));

			// Push this vertex data to the vertices vector
			this->vertices.push_back(currentVertex.x);
			this->vertices.push_back(currentVertex.y);
			this->vertices.push_back(currentVertex.z);

			textureCoordinates.x = currentVertex.x;
			textureCoordinates.y = currentVertex.z;

			this->vertices.push_back(textureCoordinates.x);
			this->vertices.push_back(textureCoordinates.y);

			normals.x = currentVertex.x;
			normals.y = currentVertex.y;
			normals.z = currentVertex.z;

			this->vertices.push_back(normals.x);
			this->vertices.push_back(normals.y);
			this->vertices.push_back(normals.z);

			this->nVertices++;
		}
	};

	// Calculate the indices for the cylinder
	// (this was really tricky and I wanted to rip my hair out
	// but such is the life of a programmer)
	void calculateIndices() {
		for (unsigned int i = 0; i < (this->nVertices / 2) - 1; i++) {
			this->indices.push_back(i - i);

			this->indices.push_back(i + 1);
			
			if (i + 2 >= this->nVertices / 2) {
				this->indices.push_back(1);
			}
			else {
				this->indices.push_back(i + 2);
			}
		}

		for (unsigned int i = this->nVertices / 2; i < this->nVertices - 1; i++) {
			this->indices.push_back(this->nVertices / 2);

			this->indices.push_back(i + 1);

			if (i + 2 >= this->nVertices) {
				this->indices.push_back(this->nVertices / 2 + 1);
			}
			else {
				this->indices.push_back(i + 2);
			}
		}

		for (unsigned int i = 0; i < (this->nVertices / 2) - 1; i++) {

			unsigned int firstIndex;
			unsigned int secondIndex;
			unsigned int thirdIndex;

			if (i + 1 == (this->nVertices / 2)) {
				firstIndex = i + 2;
			}
			else {
				firstIndex = i + 1;
			}

			secondIndex = (this->nVertices / 2) + (i + 1);

			if (i + 2 == (this->nVertices)) {
				thirdIndex = i + 3;
			}
			else if (i + 2 >= (this->nVertices / 2)) {
				thirdIndex = 1;
			}
			else {
				thirdIndex = i + 2;
			}

			for (unsigned char o = 0; o < 3; o++) {
				this->indices.push_back(firstIndex);
				this->indices.push_back(secondIndex);
				this->indices.push_back(thirdIndex);
			}

			if (i + 2 == (this->nVertices / 2)) {
				firstIndex = i + 3;
			}
			else {
				firstIndex = i + 2;
			}

			secondIndex = (this->nVertices / 2) + (i + 1);

			if ((this->nVertices / 2) + (i + 2) == (this->nVertices / 2)) {
				thirdIndex = (this->nVertices / 2) + (i + 3);
			}
			else if ((this->nVertices / 2) + (i + 2) >= this->nVertices) {
				thirdIndex = 1;
			}
			else {
				thirdIndex = (this->nVertices / 2) + (i + 2);
			}

			for (unsigned char o = 0; o < 3; o++) {
				this->indices.push_back(firstIndex);
				this->indices.push_back(secondIndex);
				this->indices.push_back(thirdIndex);
			}
		}

		this->nIndices = this->indices.size();
	};

	// Get the height for the cylinder
	float getHeight() {
		return this->height;
	}

	// Get the radius for the cylinder
	float getRadius() {
		return this->radius;
	}
};

class Plane : public Mesh {
private:
	float width;
	float length;

public:
	Plane(float width, float length) {
		this->width = width;
		this->length = length;

		glm::vec3 currentVertex = glm::vec3(
			this->length / 2.0f,
			0.0f,
			this->width / 2.0f
		);

		glm::vec2 textureCoordinates = glm::vec2(1.0f, 0.0f);
		glm::vec3 normals = glm::vec3(1.0f, -0.0f, 0.0f);

		this->vertices.push_back(currentVertex.x);
		this->vertices.push_back(currentVertex.y);
		this->vertices.push_back(currentVertex.z);

		this->vertices.push_back(textureCoordinates.x);
		this->vertices.push_back(textureCoordinates.y);

		this->vertices.push_back(normals.x);
		this->vertices.push_back(normals.y);
		this->vertices.push_back(normals.z);

		this->nVertices++;

		for (unsigned int i = 0; i < 3; i++) {
			if (i % 2 == 0) {
				currentVertex.x = -(currentVertex.x);
				currentVertex.z = currentVertex.z;

				this->vertices.push_back(currentVertex.x);
				this->vertices.push_back(currentVertex.y);
				this->vertices.push_back(currentVertex.z);

				if (i == 0) {
					textureCoordinates.x = 0.0f;
					textureCoordinates.y = 0.0f;

					this->vertices.push_back(textureCoordinates.x);
					this->vertices.push_back(textureCoordinates.y);

					normals.x = -1.0f;
					normals.y = 0.0f;
					normals.z = 0.0f;

					this->vertices.push_back(normals.x);
					this->vertices.push_back(normals.y);
					this->vertices.push_back(normals.z);
				}
				else if (i == 2) {
					textureCoordinates.x = 0.0f;
					textureCoordinates.y = 1.0f;

					this->vertices.push_back(textureCoordinates.x);
					this->vertices.push_back(textureCoordinates.y);

					normals.x = -1.0f;
					normals.y = 0.0f;
					normals.z = 0.0f;

					this->vertices.push_back(normals.x);
					this->vertices.push_back(normals.y);
					this->vertices.push_back(normals.z);
				}
			}
			else {
				currentVertex.x = -(currentVertex.x);
				currentVertex.z = -(currentVertex.z);

				this->vertices.push_back(currentVertex.x);
				this->vertices.push_back(currentVertex.y);
				this->vertices.push_back(currentVertex.z);

				if (i == 1) {
					textureCoordinates.x = 1.0f;
					textureCoordinates.y = 1.0f;

					this->vertices.push_back(textureCoordinates.x);
					this->vertices.push_back(textureCoordinates.y);

					normals.x = 1.0f;
					normals.y = 0.0f;
					normals.z = 0.0f;

					this->vertices.push_back(normals.x);
					this->vertices.push_back(normals.y);
					this->vertices.push_back(normals.z);
				}
			}

			this->nVertices++;
		}

		for (unsigned int i = 0; i < (this->nVertices / 2); i++) {
			this->indices.push_back(i);
			this->indices.push_back(i + 1);
			this->indices.push_back(i + 2);

			this->nIndices += 3;
		}
	}
};

class Texture {
public:
	unsigned int textureId;
	unsigned int slot;
	const char* file_path;
	bool background;

	Texture(const char* path, unsigned int slot, bool bg) {
		this->file_path = path;
		this->slot = slot;
		this->background = bg;

		if (!this->Create()) {
			std::cout << "Can't create texture from file " << this->file_path << std::endl;
		}
	}
	
	~Texture() {
		glGenTextures(1, &this->textureId);
	}

	bool Create() {
		int width, height, channels;

		unsigned char* image = stbi_load(this->file_path, &width, &height, &channels, 0);

		if (image) {
			flipImageVertically(image, width, height, channels);

			glGenTextures(1, &this->textureId);
			glBindTexture(GL_TEXTURE_2D, this->textureId);

			if (this->background) {
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
			}
			else {
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
			}

			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

			if (channels == 3) {
				glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
			}
			else if (channels == 4) {
				glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
			}
			else {
				std::cout << "Error handling image with " << channels << " channels" << std::endl;
				return false;
			}

			glGenerateMipmap(GL_TEXTURE_2D);

			stbi_image_free(image);
			glBindTexture(GL_TEXTURE_2D, 0);

			return true;
		}

		return false;
	}
};

class Light {
public:
	unsigned int VAO;
	unsigned int VBO;
	unsigned int nVertices = 0;
	unsigned int nIndices = 0;
	std::vector<float> vertices;
	glm::vec3 lightColor = glm::vec3(1.0f);
	glm::vec3 lightPosition = glm::vec3(0.0f);
	glm::vec3 lightScale = glm::vec3(0.1f);
	float linear = 0.22f;
	float quadratic = 0.2f;
	float constant = 1.0f;

	Light(glm::vec3 pos, glm::vec3 color) {
		this->lightPosition = pos;
		this->lightColor = color;

		std::vector<float> verts = {
			// Front face
			 0.0f,  0.5f,  0.0f,    0.0f,  0.0f,  1.0f,
			-0.5f, -0.5f,  0.5f,    0.0f,  0.0f,  1.0f,
			 0.5f, -0.5f,  0.5f,    0.0f,  0.0f,  1.0f,

			 // Right face
			 0.0f,  0.5f,  0.0f,    1.0f,  0.0f,  0.0f,
			 0.5f, -0.5f,  0.5f,    1.0f,  0.0f,  0.0f,
			 0.5f, -0.5f, -0.5f,    1.0f,  0.0f,  0.0f,

			 // Back face
			 0.0f,  0.5f,  0.0f,    0.0f,  0.0f, -1.0f,
			 0.5f, -0.5f, -0.5f,    0.0f,  0.0f, -1.0f,
			-0.5f, -0.5f, -0.5f,    0.0f,  0.0f, -1.0f,

			// Left face
			0.0f,  0.5f,  0.0f,   -1.0f,  0.0f,  0.0f,
		   -0.5f, -0.5f, -0.5f,   -1.0f,  0.0f,  0.0f,
		   -0.5f, -0.5f,  0.5f,   -1.0f,  0.0f,  0.0f,

		   // Base
		  -0.5f, -0.5f,  0.5f,    0.0f, -1.0f,  0.0f,
		   0.5f, -0.5f,  0.5f,    0.0f, -1.0f,  0.0f,
		  -0.5f, -0.5f, -0.5f,    0.0f, -1.0f,  0.0f,
		  -0.5f, -0.5f, -0.5f,    0.0f, -1.0f,  0.0f,
		   0.5f, -0.5f, -0.5f,    0.0f, -1.0f,  0.0f,
		   0.5f, -0.5f,  0.5f,    0.0f, -1.0f,  0.0f,
		};

		this->vertices.insert(this->vertices.end(), verts.begin(), verts.end());

		this->nVertices = this->vertices.size();
	}
};

// This is for catching errors thrown by OpenGL
void GLAPIENTRY MessageCallback(GLenum source,
	GLenum type,
	GLuint id,
	GLenum severity,
	GLsizei length,
	const GLchar* message,
	const void* userParam) {
	fprintf(stderr, "GL CALLBACK: %s type = 0x%x, severity = 0x%x, message = %s\n",
		(type == GL_DEBUG_TYPE_ERROR ? "** GL ERROR **" : ""),
		type, severity, message);
}

// Vertex shader
const char* vertex_shader = "#version 440 core\n"
"layout (location = 0) in vec3 position;\n"
"layout (location = 1) in vec2 textureCoords;\n"
"layout (location = 2) in vec3 normal;\n"
"out vec2 vertexTextureCoords;\n"
"out vec3 vertexNormal;\n"
"out vec3 vertexFragmentPos;\n"
"uniform mat4 model;\n"
"uniform mat4 view;\n"
"uniform mat4 projection;\n"
"void main()\n"
"{\n"
"   gl_Position = projection * view * model * vec4(position.x, position.y, position.z, 1.0);\n"
"   vertexTextureCoords = textureCoords;\n"
"   vertexFragmentPos = vec3(model * vec4(position, 1.0f));\n"
"   vertexNormal = mat3(transpose(inverse(model))) * normal;\n"
"}\0";

// Fragment shader
const char* fragment_shader = "#version 440 core\n"
"in vec2 vertexTextureCoords;\n"
"in vec3 vertexNormal;\n"
"in vec3 vertexFragmentPos;\n"
"out vec4 fragmentColor;\n"
"uniform float lightLinear;\n"
"uniform float lightConstant;\n"
"uniform float lightQuadratic;\n"
"uniform vec3 objectColor;\n"
"uniform vec3 lightColor;\n"
"uniform vec3 lightPos;\n"
"uniform vec3 viewPosition;\n"
"uniform sampler2D uTexture;\n"
"uniform vec2 uvScale;\n"
"void main()\n"
"{\n"
"   float distance = length(lightPos - vertexFragmentPos);\n"
"   float attenuation = 1.0 / (lightConstant + lightLinear * distance + lightQuadratic * (distance * distance));\n"
"   float ambientStrength = 0.5f;\n"
"   vec3 ambient = ambientStrength * lightColor * vec3(texture(uTexture, vertexTextureCoords * uvScale));\n"
"   vec3 norm = normalize(vertexNormal);\n"
"   vec3 lightDirection = normalize(lightPos - vertexFragmentPos);\n"
"   float impact = max(dot(norm, lightDirection), 0.0);\n"
"   vec3 diffuse = impact * lightColor * vec3(texture(uTexture, vertexTextureCoords * uvScale));\n"
"   float specularIntensity = 0.8f;\n"
"   float highlightSize = 16.0f;\n"
"   vec3 viewDir = normalize(viewPosition - vertexFragmentPos);\n"
"   vec3 reflectDir = reflect(-lightDirection, norm);\n"
"   float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);\n"
"   vec3 specular = specularIntensity * specularComponent * lightColor * vec3(texture(uTexture, vertexTextureCoords * uvScale));\n"
"   ambient *= attenuation;\n"
"   diffuse *= attenuation;\n"
"   specular *= attenuation;\n"
"   vec3 phong = (ambient + diffuse + specular) * objectColor;\n"
"   fragmentColor = vec4(phong, 1.0f);\n"
"}\n\0";

// "   fragmentColor = texture(uTexture, vertexTextureCoords * uvScale);\n"

const char* light_vertex_shader = "#version 440 core\n"
"layout (location = 0) in vec3 position;\n"
"uniform mat4 model;\n"
"uniform mat4 view;\n"
"uniform mat4 projection;\n"
"void main()\n"
"{\n"
"   gl_Position = projection * view * model * vec4(position, 1.0f);\n"
"}\n\0";

const char* light_fragment_shader = "#version 440 core\n"
"out vec4 fragmentColor;\n"
"void main()\n"
"{\n"
"   fragmentColor = vec4(1.0f);\n"
"}\n\0";

// ---- Methods ----
bool Initialize();
void ProcessInput(GLFWwindow* window);
void ResizeWindow(GLFWwindow* window, int width, int height);
void CreateMesh(Mesh& mesh);
void CreateLight(Light& light);
void DestroyMesh(Mesh& mesh);
void DestroyLight(Light& light);
bool CreateShader(const char* vtxShaderSrc, const char* fragShaderSrc, unsigned int& shaderProgramId);
void DestroyShader(unsigned int shaderProgramId);
void RenderMesh(Mesh& mesh, Light& light, float ang, glm::vec3 ax, bool wireframe, glm::vec3 pos, Texture& texture);
void RenderLight(Light& light, float ang, glm::vec3 pos);
void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods);
void MousePositionCallback(GLFWwindow* window, double xPos, double yPos);
void MouseScrollCallback(GLFWwindow* window, double xOffest, double yOffset);

// ---- main ----
int main() {
	gCamera.MovementSpeed = normalCamSpeed;

	// Check to see if we could initialize properly
	if (!Initialize()) {
		// Display a warning saying we couldn't initialize the application
		std::cout << "Could not initialize application" << std::endl;

		// Return with a code of -1, unsuccessful
		return -1;
	}

	Plane plane(0.3f, 1.0f);
	CreateMesh(plane);

	Plane plane2(0.03f, 1.0f);
	CreateMesh(plane2);

	Plane plane3(0.03f, 1.0f);
	CreateMesh(plane3);

	Plane plane4(0.03f, 1.0f);
	CreateMesh(plane4);

	Plane plane5(0.03f, 1.0f);
	CreateMesh(plane5);

	Plane plane6(0.03f, 1.0f);
	CreateMesh(plane6);

	Plane plane7(0.5f, 1.0f);
	CreateMesh(plane7);

	Cylinder tableTop(100, 0.06f, 0.005f);
	CreateMesh(tableTop);

	Cylinder tablePole(100, 0.004f, 0.12f);
	CreateMesh(tablePole);

	Cylinder tableBase(4, 0.03f, 0.004f);
	CreateMesh(tableBase);

	Cylinder tableTop2(4, 0.06f, 0.005f);
	CreateMesh(tableTop2);

	Cylinder tablePole2(100, 0.004f, 0.12f);
	CreateMesh(tablePole2);

	Cylinder tableBase2(4, 0.03f, 0.004f);
	CreateMesh(tableBase2);

	Cylinder tableTop3(4, 0.06f, 0.005f);
	CreateMesh(tableTop3);

	Cylinder tablePole3(100, 0.004f, 0.12f);
	CreateMesh(tablePole3);

	Cylinder tableBase3(4, 0.03f, 0.004f);
	CreateMesh(tableBase3);

	Cylinder tableTop4(100, 0.06f, 0.005f);
	CreateMesh(tableTop4);

	Cylinder tablePole4(100, 0.004f, 0.12f);
	CreateMesh(tablePole4);

	Cylinder tableBase4(4, 0.03f, 0.004f);
	CreateMesh(tableBase4);

	Plane backWall(0.65f, 1.0f);
	CreateMesh(backWall);

	Plane leftWall(0.86f, 0.65f);
	CreateMesh(leftWall);

	Plane rightWall(0.86f, 0.65f);
	CreateMesh(rightWall);

	Light light(glm::vec3(-0.35f, 0.41f, -0.6f), glm::vec3(0.9f, 1.0f, 0.9f));
	CreateLight(light);

	Cylinder lightPole1(100, 0.005f, 0.12f);
	CreateMesh(lightPole1);

	Cylinder lightPole2(100, 0.005f, 0.12f);
	CreateMesh(lightPole2);

	Light light2(glm::vec3(0.4f, 0.41f, 0.0f), glm::vec3(1.0f, 1.0f, 1.0f));
	CreateLight(light2);

	// Check to see if we could create shaders successfully
	if (!CreateShader(vertex_shader, fragment_shader, shaderProgramId)) {
		// We couldn't, so print an error
		std::cout << "Shaders could not be created" << std::endl;

		// Return with an unsuccessful exit code
		return -1;
	}

	if (!CreateShader(light_vertex_shader, light_fragment_shader, lightProgramId)) {
		std::cout << "Light shaders could not be created" << std::endl;

		return -1;
	}

	glEnable(GL_DEBUG_OUTPUT);
	glDebugMessageCallback(MessageCallback, 0);

	Texture ground("./resources/textures/slate.png", 0, false);
	Texture marble("./resources/textures/marble.jpg", 1, false);
	Texture metal("./resources/textures/metal.jpg", 2, false);
	Texture wood("./resources/textures/wood.jpg", 3, false);
	Texture background("./resources/textures/bricks.png", 4, false);
	Texture background2("./resources/textures/bricks2.png", 5, false);

	/* Enter the rendering loop
	   Essentially, while the window should remain open,
	   we process each frame */
	while (!glfwWindowShouldClose(window)) {
		// Perform frame calculations for camera movement
		double currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// Before we do anything, process input
		ProcessInput(window);

		// Enable GL_DEPTH_TEST for 3D rendering
		glEnable(GL_DEPTH_TEST);
		
		// Set the clear color
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

		// Clear the color buffer and depth buffer
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glUseProgram(shaderProgramId);

		uv_scale = glm::vec2(10.0f, 10.0f);
		glUniform1i(glGetUniformLocation(shaderProgramId, "uTexture"), marble.slot);
		
		RenderMesh(
			tableTop,
			light2,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(0.35f, tablePole.getHeight() + tableBase.getHeight() + (tableTop.getHeight() / 2), 0.0f),
			marble
		);

		RenderMesh(
			tableTop4,
			light,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(-0.35f, (tablePole4.getHeight() + tableBase4.getHeight() + (tableTop4.getHeight() / 2)) - 0.09f, -0.5f),
			marble
		);

		uv_scale = glm::vec2(1.0f, 1.0f);
		glUniform1i(glGetUniformLocation(shaderProgramId, "uTexture"), metal.slot);

		RenderMesh(
			tablePole,
			light2,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(0.35f, tableBase.getHeight() + (tablePole.getHeight() / 2), 0.0f),
			metal
		);

		RenderMesh(
			tableBase,
			light2,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(0.35f, tableBase.getHeight() / 2, 0.0f),
			metal
		);

		RenderMesh(
			tablePole2,
			light,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(-0.35f, tableBase2.getHeight() + (tablePole2.getHeight() / 2), 0.0f),
			metal
		);

		RenderMesh(
			tableBase2,
			light,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(-0.35f, tableBase2.getHeight() / 2, 0.0f),
			metal
		);

		RenderMesh(
			tablePole3,
			light2,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(0.35f, (tableBase3.getHeight() + (tablePole3.getHeight() / 2)) - 0.09f, -0.5f),
			metal
		);

		RenderMesh(
			tableBase3,
			light2,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(0.35f, (tableBase3.getHeight() / 2) - 0.09f, -0.5f),
			metal
		);

		RenderMesh(
			tablePole4,
			light2,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(-0.35f, (tableBase4.getHeight() + (tablePole4.getHeight() / 2)) - 0.09f, -0.5f),
			metal
		);

		RenderMesh(
			tableBase4,
			light2,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(-0.35f, (tableBase4.getHeight() / 2) - 0.09f, -0.5f),
			metal
		);

		RenderMesh(
			lightPole1,
			light,
			0.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(-0.35f, 0.4f, -0.66f),
			metal
		);

		RenderMesh(
			lightPole2,
			light2,
			180.0f,
			glm::vec3(1.0f, 0.0f, 1.0f),
			false,
			glm::vec3(0.44f, 0.4f, 0.0f),
			metal
		);
		

		uv_scale = glm::vec2(2.0f, 4.0f);
		glUniform1i(glGetUniformLocation(shaderProgramId, "uTexture"), ground.slot);

		RenderMesh(plane, light, 0.0f, glm::vec3(1.0f, 0.0f, 0.0f), false, glm::vec3(0.0f, 0.0f, 0.0f), ground);
		RenderMesh(plane2, light, 90.0f, glm::vec3(1.0f, 0.0f, 0.0f), false, glm::vec3(0.0f, -0.015f, -0.15f), ground);
		RenderMesh(plane3, light, 0.0f, glm::vec3(1.0f, 0.0f, 0.0f), false, glm::vec3(0.0f, -0.03f, -0.165f), ground);
		RenderMesh(plane4, light, 90.0f, glm::vec3(1.0f, 0.0f, 0.0f), false, glm::vec3(0.0f, -0.045f, -0.18f), ground);
		RenderMesh(plane5, light, 0.0f, glm::vec3(1.0f, 0.0f, 0.0f), false, glm::vec3(0.0f, -0.06f, -0.195f), ground);
		RenderMesh(plane6, light, 90.0f, glm::vec3(1.0f, 0.0f, 0.0f), false, glm::vec3(0.0f, -0.075f, -0.21f), ground);
		RenderMesh(plane7, light, 0.0f, glm::vec3(1.0f, 0.0f, 0.0f), false, glm::vec3(0.0f, -0.09f, -0.46f), ground);

		uv_scale = glm::vec2(1.0f, 1.0f);
		glUniform1i(glGetUniformLocation(shaderProgramId, "uTexture"), wood.slot);

		RenderMesh(
			tableTop2,
			light,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(-0.35f, tablePole2.getHeight() + tableBase2.getHeight() + (tableTop2.getHeight() / 2), 0.0f),
			wood
		);

		RenderMesh(
			tableTop3,
			light2,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(0.35f, (tablePole3.getHeight() + tableBase3.getHeight() + (tableTop3.getHeight() / 2)) - 0.09f, -0.5f),
			wood
		);

		uv_scale = glm::vec2(3.0f, 3.0f);
		glUniform1i(glGetUniformLocation(shaderProgramId, "uTexture"), background.slot);

		RenderMesh(
			backWall,
			light,
			90.0f,
			glm::vec3(1.0f, 0.0f, 0.0f),
			false,
			glm::vec3(0.0f, 0.235f, -0.71f),
			background
		);

		uv_scale = glm::vec2(3.0f, 3.0f);
		glUniform1i(glGetUniformLocation(shaderProgramId, "uTexture"), background2.slot);

		RenderMesh(
			leftWall,
			light,
			90.0f,
			glm::vec3(0.0f, 0.0f, 1.0f),
			false,
			glm::vec3(-0.5f, 0.235f, -0.28f),
			background2
		);

		RenderMesh(
			rightWall,
			light2,
			90.0f,
			glm::vec3(0.0f, 0.0f, 1.0f),
			false,
			glm::vec3(0.5f, 0.235f, -0.28f),
			background2
		);

		RenderLight(light, 90.0f, light.lightPosition);
		RenderLight(light2, 90.0f, light2.lightPosition);

		// Swap the front and back buffers each frame
		glfwSwapBuffers(window);

		// Poll for events to keep the application responsive
		glfwPollEvents();
	}

	/* At this point in the program, the window
	   has been signaled to close, so we can handle
	   certain terminating tasks here */

	DestroyLight(light);
	DestroyLight(light2);

	DestroyMesh(plane);
	DestroyMesh(plane2);
	DestroyMesh(plane3);
	DestroyMesh(plane4);
	DestroyMesh(plane5);
	DestroyMesh(plane6);
	DestroyMesh(plane7);

	DestroyMesh(tableTop);
	DestroyMesh(tablePole);
	DestroyMesh(tableBase);

	DestroyMesh(tableTop2);
	DestroyMesh(tablePole2);
	DestroyMesh(tableBase2);

	DestroyMesh(tableTop3);
	DestroyMesh(tablePole3);
	DestroyMesh(tableBase3);

	DestroyMesh(tableTop4);
	DestroyMesh(tablePole4);
	DestroyMesh(tableBase4);

	DestroyMesh(backWall);
	DestroyMesh(leftWall);
	DestroyMesh(rightWall);

	DestroyMesh(lightPole1);
	DestroyMesh(lightPole2);

	DestroyShader(shaderProgramId);

	return 0;
}

// Initialize GLFW and glew, and create a window
bool Initialize() {
	// Before we do anything, we need to initialize GLFW
	glfwInit();

	/* Send hints to the window indicating which
	   version of OpenGL it must be compatible with */
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);

	// Create the window
	window = glfwCreateWindow(
		WINDOW_WIDTH, // Set the window width
		WINDOW_HEIGHT, // Set the window height
		WINDOW_TITLE, // Set the window title
		NULL, /* We don't specify a monitor because
				 it's not going to be in fullscreen */
		NULL // Not sure what this is, not important
	);

	// Check to see if the window was created successfully
	if (window == NULL) {
		// Print a message warning something bad happened
		std::cout << "The window could not be created!" << std::endl;

		// Terminate the GLFW instance
		glfwTerminate();

		// Return false, meaning unsuccessful in this case
		return false;
	}

	// Make the current context the window we just (hopefully) created
	glfwMakeContextCurrent(window);

	// Set the callback for the window resize
	glfwSetFramebufferSizeCallback(window, ResizeWindow);

	// Set input callbacks
	glfwSetKeyCallback(window, KeyCallback);
	glfwSetCursorPosCallback(window, MousePositionCallback);
	glfwSetScrollCallback(window, MouseScrollCallback);

	GLFWimage images[1];
	images[0].pixels = stbi_load("./flag-round-250.png", &images[0].width, &images[0].height, 0, 0);
	glfwSetWindowIcon(window, 1, images);
	stbi_image_free(images[0].pixels);

	// Make the cursor disappear for easier mouse controls
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// Now we must initialize glew
	glewExperimental = true;

	// Initialize glew
	int glew_init = glewInit();

	// Check to see if glew initialized properly
	if (glew_init != GLEW_OK) {
		// Display a warning message if it didn't
		std::cout << "Could not initialize glew" << std::endl;

		// Return with false, meaning unsuccessful
		return false;
	}

	return true;
}

// Process input for the specified window
void ProcessInput(GLFWwindow* window) {
	// The escape key signals the window to close
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, true);
	}

	// The W key moves the camera forward
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
		//cameraPosition += cameraOffset * cameraFront;
		gCamera.ProcessKeyboard(FORWARD, deltaTime);
	}

	// The A key moves the camera leftward
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
		//cameraPosition -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraOffset;
		gCamera.ProcessKeyboard(LEFT, deltaTime);
	}

	// The S key moves the camera backward
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
		//cameraPosition -= cameraOffset * cameraFront;
		gCamera.ProcessKeyboard(BACKWARD, deltaTime);
	}

	// The D key moves the camera rightward
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
		//cameraPosition += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraOffset;
		gCamera.ProcessKeyboard(RIGHT, deltaTime);
	}

	// The Q key moves the camera straight up
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
		gCamera.ProcessKeyboard(UP, deltaTime);
	}

	// The E key moves the camera straight down
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
		gCamera.ProcessKeyboard(DOWN, deltaTime);
	}
}

void ResizeWindow(GLFWwindow* window, int width, int height) {
	glViewport(0, 0, width, height);
	aspectRatio = (float)width / (float)height;
}

void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	// Holding down the shift key makes the camera travel slower
	if (key == GLFW_KEY_LEFT_SHIFT && action == GLFW_PRESS) {
		//cameraSpeed = slowCamSpeed;
		gCamera.MovementSpeed = slowCamSpeed;
	}

	// Releasing the shift key returns the camera to its normal speed
	if (key == GLFW_KEY_LEFT_SHIFT && action == GLFW_RELEASE) {
		//cameraSpeed = normalCamSpeed;
		gCamera.MovementSpeed = gCamera.MovementSpeed;
	}

	if (key == GLFW_KEY_P && action == GLFW_PRESS) {
		if (projection == perspective) {
			projection = orthographic;
		}
		else {
			projection = perspective;
		}
	}
}

void MousePositionCallback(GLFWwindow* window, double xPos, double yPos) {
	// I just copied the code from the tutorial because it's weird.

	if (gFirstMouse)
	{
		gLastX = xPos;
		gLastY = yPos;
		gFirstMouse = false;
	}

	float xoffset = xPos - gLastX;
	float yoffset = gLastY - yPos; // reversed since y-coordinates go from bottom to top

	gLastX = xPos;
	gLastY = yPos;

	gCamera.ProcessMouseMovement(xoffset, yoffset);
}

void MouseScrollCallback(GLFWwindow* window, double xOffset, double yOffset) {
	// Changes the FOV or something
	gCamera.ProcessMouseScroll(yOffset);
}

// Creates a mesh
void CreateMesh(Mesh& mesh) {
	// Generate and bind the vertex array object for our mesh
	glGenVertexArrays(1, &mesh.VAO);
	glBindVertexArray(mesh.VAO);

	// Generate two vertex buffer objects, one for vertices and one for indices
	glGenBuffers(2, mesh.VBOs);

	// Bind the first buffer and give it our vertices
	glBindBuffer(GL_ARRAY_BUFFER, mesh.VBOs[0]);
	glBufferData(GL_ARRAY_BUFFER, mesh.vertices.size() * sizeof(float), mesh.vertices.data(), GL_STATIC_DRAW);

	// Bind the second buffer and give it our indices
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.VBOs[1]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, mesh.indices.size() * sizeof(unsigned int), mesh.indices.data(), GL_STATIC_DRAW);

	// Set the number of floats per vertex and color
	unsigned int floatsPerVertex = 3;
	unsigned int floatsPerUV = 2;
	unsigned int floatsPerNormal = 3;

	// Use these to calculate the stride between vertices
	unsigned int stride = sizeof(float) * (floatsPerVertex + floatsPerUV + floatsPerNormal);

	// Tell OpenGL stuff about where to find our vertex position data
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, NULL);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerUV));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerNormal));
	glEnableVertexAttribArray(2);
}

void CreateLight(Light& light) {
	// Set the number of vertices and indices in the mesh
	//mesh.nVertices = sizeof(vertices) / sizeof(float);
	//mesh.nIndices = sizeof(indices) / sizeof(float);

	// Generate and bind the vertex array object for our mesh
	glGenVertexArrays(1, &light.VAO);
	glBindVertexArray(light.VAO);

	// Generate two vertex buffer objects, one for vertices and one for indices
	glGenBuffers(1, &light.VBO);

	// Bind the first buffer and give it our vertices
	glBindBuffer(GL_ARRAY_BUFFER, light.VBO);
	glBufferData(GL_ARRAY_BUFFER, light.vertices.size() * sizeof(float), light.vertices.data(), GL_STATIC_DRAW);

	// Set the number of floats per vertex and color
	unsigned int floatsPerVertex = 3;
	unsigned int floatsPerNormal = 3;

	// Use these to calculate the stride between vertices
	unsigned int stride = sizeof(float) * (floatsPerVertex + floatsPerNormal);

	// Tell OpenGL stuff about where to find our vertex position data
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, NULL);
	glEnableVertexAttribArray(0);

	// Tell OpenGL stuff about our normals
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerNormal));
	glEnableVertexAttribArray(1);
}

// Destroy a mesh
void DestroyMesh(Mesh& mesh) {
	glDeleteVertexArrays(1, &mesh.VAO);
	glDeleteBuffers(2, mesh.VBOs);
}

void DestroyLight(Light& light) {
	glDeleteVertexArrays(1, &light.VAO);
	glDeleteBuffers(1, &light.VBO);
}

// Create a shader program
bool CreateShader(const char* vtxShaderSrc, const char* fragShaderSrc, unsigned int& shaderProgramId) {
	// Create a shader program and get its ID
	shaderProgramId = glCreateProgram();
	
	int success = 0;
	char infoLog[512];

	// Create the shaders and store their IDs for future use
	unsigned int vtxShaderId = glCreateShader(GL_VERTEX_SHADER);
	unsigned int fragShaderId = glCreateShader(GL_FRAGMENT_SHADER);

	// Get the source of the shaders....
	glShaderSource(vtxShaderId, 1, &vtxShaderSrc, NULL);
	glShaderSource(fragShaderId, 1, &fragShaderSrc, NULL);

	// Compile the vertex shader
	glCompileShader(vtxShaderId);

	// Get the status of the vertex shader compilation
	glGetShaderiv(vtxShaderId, GL_COMPILE_STATUS, &success);

	// Check to see if the vertex shader compiled correctly
	if (!success) {
		// Didn't compile successfully, so get the error information
		glGetShaderInfoLog(vtxShaderId, sizeof(infoLog), NULL, infoLog);

		// Print it
		std::cout << "VERTEX SHADER COMPILATION ERROR:\n" << infoLog << std::endl;

		// Return false so that the calling function can handle it properly
		return false;
	}

	// Compile the fragment shader
	glCompileShader(fragShaderId);

	// Get the status of the fragment shader compilation
	glGetShaderiv(fragShaderId, GL_COMPILE_STATUS, &success);

	// Check to see if the fragment shader compilation was successful
	if (!success) {
		// It wasn't successful, so get the error details
		glGetShaderInfoLog(fragShaderId, sizeof(infoLog), NULL, infoLog);

		// Print it
		std::cout << "FRAGMENT SHADER COMPILATION ERROR:\n" << infoLog << std::endl;

		// Return false so that the calling function can handle it properly
		return false;
	}

	// And attach the actual compiled source code to the shader program....
	glAttachShader(shaderProgramId, vtxShaderId);
	glAttachShader(shaderProgramId, fragShaderId);

	// Link the shader program
	glLinkProgram(shaderProgramId);

	// Get the status of the shader program linkage
	glGetProgramiv(shaderProgramId, GL_LINK_STATUS, &success);

	// Check to see if the shader program linkage was successful
	if (!success) {
		// It wasn't, so get the error information
		glGetProgramInfoLog(shaderProgramId, sizeof(infoLog), NULL, infoLog);

		// Print it
		std::cout << "SHADER PROGRAM LINKAGE FAILED:\n" << infoLog << std::endl;

		// Return false so that the calling function can properly handle the error
		return false;
	}

	// No errors were thrown, return true to the calling function
	return true;
}

// Destroy a shader program
void DestroyShader(unsigned int shaderProgramId) {
	glDeleteProgram(shaderProgramId);
}

// Render a mesh
void RenderMesh(Mesh& mesh, Light& light, float ang, glm::vec3 ax, bool wireframe, glm::vec3 pos, Texture& texture) {
	// Create a scale matrix to scale the object by a given scalar
	float scalar = 1.0f;
	glm::mat4 scale = glm::scale(glm::vec3(scalar, scalar, scalar));

	// Create a rotation matrix to rotate the object by an angle and on the specified axes
	//float rotationAngle = 3.14f;
	float rotationAngle = ang * (PI / 180.0f);
	//glm::vec3 axes = ax; // 1.0f = rotate on that axis, 0.0f = no

	glm::mat4 rotation = glm::rotate(rotationAngle, ax);

	// Create a translation matrix to translate the object across 3D space
	glm::mat4 translation = glm::translate(pos);

	// Get the entire transformation matrix with all of these applied
	// They are applied in right-to-left order: scale -> rotate -> translate
	glm::mat4 model = translation * rotation;// * scale;

	// Get the view matrix from the camera controls
	glm::mat4 view = gCamera.GetViewMatrix();

	// Tell open the shader program we want to use for the next few operations
	glUseProgram(shaderProgramId);

	// Get the location in memory of the model, view, and projection matrices
	unsigned int modelLoc = glGetUniformLocation(shaderProgramId, "model");
	unsigned int viewLoc = glGetUniformLocation(shaderProgramId, "view");
	unsigned int projectionLoc = glGetUniformLocation(shaderProgramId, "projection");

	// Pass these matrices to the vertex shader
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));

	unsigned int uvScaleLoc = glGetUniformLocation(shaderProgramId, "uvScale");
	glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uv_scale));

	unsigned int objectColorLoc = glGetUniformLocation(shaderProgramId, "objectColor");
	unsigned int lightColorLoc = glGetUniformLocation(shaderProgramId, "lightColor");
	unsigned int lightPositionLoc = glGetUniformLocation(shaderProgramId, "lightPos");
	unsigned int viewPositionLoc = glGetUniformLocation(shaderProgramId, "viewPosition");

	glUniform3f(objectColorLoc, mesh.objectColor.r, mesh.objectColor.g, mesh.objectColor.b);
	glUniform3f(lightColorLoc, light.lightColor.r, light.lightColor.g, light.lightColor.b);
	glUniform3f(lightPositionLoc, light.lightPosition.x, light.lightPosition.y, light.lightPosition.z);

	unsigned int lightConstantLoc = glGetUniformLocation(shaderProgramId, "lightConstant");
	unsigned int lightLinearLoc = glGetUniformLocation(shaderProgramId, "lightLinear");
	unsigned int lightQuadraticLoc = glGetUniformLocation(shaderProgramId, "lightQuadratic");

	glUniform1f(lightConstantLoc, light.constant);
	glUniform1f(lightLinearLoc, light.linear);
	glUniform1f(lightQuadraticLoc, light.quadratic);

	const glm::vec3 cameraPosition = gCamera.Position;
	glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

	// Bind the vertex array of the mesh to be used
	glBindVertexArray(mesh.VAO);

	if (texture.slot == 0) {
		glActiveTexture(GL_TEXTURE0);
	}
	else if (texture.slot == 1) {
		glActiveTexture(GL_TEXTURE1);
	}
	else if (texture.slot == 2) {
		glActiveTexture(GL_TEXTURE2);
	}
	else if (texture.slot == 3) {
		glActiveTexture(GL_TEXTURE3);
	}
	else if (texture.slot == 4) {
		glActiveTexture(GL_TEXTURE4);
	}
	else if (texture.slot == 5) {
		glActiveTexture(GL_TEXTURE5);
	}

	//glActiveTexture(texture.slot);
	glBindTexture(GL_TEXTURE_2D, texture.textureId);

	// If we are rendering a wireframe, do the... thing
	if (wireframe) {
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

		// Draw it!
		glDrawElements(GL_TRIANGLES, mesh.nIndices, GL_UNSIGNED_INT, nullptr);

		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}
	else {
		// If not, just draw the filled shape
		// Draw it!
		glDrawElements(GL_TRIANGLES, mesh.nIndices, GL_UNSIGNED_INT, nullptr);
	}

	// Removing the vertex array binding
	glBindVertexArray(0);
}

void RenderLight(Light& light, float ang, glm::vec3 pos) {
	// Create a scale matrix to scale the object by a given scalar
	float scalar = 1.0f;
	glm::mat4 scale = glm::scale(glm::vec3(scalar, scalar, scalar));

	// Create a rotation matrix to rotate the object by an angle and on the specified axes
	//float rotationAngle = 3.14f;
	float rotationAngle = ang * (PI / 180.0f);
	glm::vec3 axes = glm::vec3(1.0f, 0.0f, 0.0f); // 1.0f = rotate on that axis, 0.0f = no
	glm::mat4 rotation = glm::rotate(rotationAngle, axes);

	// Create a translation matrix to translate the object across 3D space
	glm::mat4 translation = glm::translate(pos);

	// Get the entire transformation matrix with all of these applied
	// They are applied in right-to-left order: scale -> rotate -> translate
	glm::mat4 model = glm::translate(light.lightPosition) * glm::scale(light.lightScale);

	glm::mat4 view = gCamera.GetViewMatrix();

	// Create a projection matrix
	float aspectRatio = (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT;

	glm::mat4 projection = glm::perspective(
		glm::radians(gCamera.Zoom),
		aspectRatio,
		0.1f,
		100.0f
	);

	glUseProgram(lightProgramId);

	// Get the location in memory of the model, view, and projection matrices
	unsigned int modelLoc = glGetUniformLocation(shaderProgramId, "model");
	unsigned int viewLoc = glGetUniformLocation(shaderProgramId, "view");
	unsigned int projectionLoc = glGetUniformLocation(shaderProgramId, "projection");

	// Pass these matrices to the vertex shader
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));

	glBindVertexArray(light.VAO);

	glDrawArrays(GL_TRIANGLES, 0, light.nVertices);

	glBindVertexArray(0);
}

// Flip an image vertically (used for textures)
void flipImageVertically(unsigned char* image, int width, int height, int channels) {
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}